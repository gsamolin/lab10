module CalcHelper
end
